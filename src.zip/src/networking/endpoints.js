// Production Urls:

// export const hrms_url = "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8088/hrms";
// export const sales_url = "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8081/sales";
// export const roleManagement_url = "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8089/role-management";
// export const ops_url = "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8084/ops"
// export const inventory_url = "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8087/inventory";
// export const vehicleServices_url = "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8083/vehicle-services";
// export const admin_url = "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8082/admin";
// export const notificationServices_url = "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8086/notification-service";
// export const vehicleInfoService_url = "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8090/vehicle-information-service";
// export const customerService_url = "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8085/customer-service";
// export const dynamicReports_url = "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8091/dynamic-reports";
// export const dynamicForms = "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8091/dynamic-forms";
// export const orgnaizationHirarchy = "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8091/oh";
// export const dashboard = "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8092/dashboard";
// export const dfGetAll = "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8091/df-get-all"
// export const subSourceAllDetails = "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8091/Source_SubSource_AllDetails"
// export const salesGap = "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8092/sales-gap"
// export const lostSubLost = "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8091/Lost_SubLost_AllDetails"

// Dev End Points
// export const hrms_url =
// "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8088/hrms";
// export const sales_url =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8081/sales";
// // "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8081/sales/account/enquiryAccount?allocateDse=false"
// export const roleManagement_url =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8089/role-management";
// export const vehicleInfoService_url =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8090/vehicle-information-service";
// export const ops_url =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8084/ops";
// export const inventory_url =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8087/inventory";
// export const vehicleServices_url =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8083/vehicle-services";
// export const admin_url =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8082/admin";
// export const notificationServices_url =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8086/notification-service";
// export const customerService_url =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8085/customer-service";
// export const dynamicReports_url =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8091/dynamic-reports";
// export const dynamicForms =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8091/dynamic-forms";
// export const orgnaizationHirarchy =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8091/oh";
// export const dashboard =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8092/dashboard";
// export const dfGetAll =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8091/df-get-all";
// export const subSourceAllDetails =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8091/Source_SubSource_AllDetails";
// export const salesGap =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8092/sales-gap";
// export const lostSubLost =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8091/Lost_SubLost_AllDetails";
// export const getBranch =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8092/oh";
// export const downloadFile =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8093/dynamic-reports";
// export const downloadFile1 =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8095/dynamic-reports/etvbrl_report_download";
// export const downloadFile2 =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8095/dynamic-reports/etvbrl_report";
// export const tasktransfer =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8092/sales-gap/target-dropdown";
// export const getTaskList =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8081/sales/task-delegation/get_task_list";
// export const getEmployeeData =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8089/role-management/employee/dept-employees";
// export const getEmployeeList =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8081/sales/employees/reporting/all/emp";
// export const getReportingMangerList =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8081/sales/employees/all/reportingManagers/orgId";
// export const updateEmployeeTaskDelegate =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8081/sales/employees/emp";
// export const getLeaderBoardData =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8092/dashboard/v2/get_emp_target_ranking/org";
// export const getBranchRankingData =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8092/dashboard/v2/get_emp_target_ranking";
// export const getEnquiryVehicleModelData =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8091/Other_Maker_AllDetails";
// export const deleteModelCard =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8081/sales/lead";
// export const dashboardLiveLeads =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8083";
// export const profileImageUpdate =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8081/sales/employeeprofilepic";

export const saveLocation =
  "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8081/sales/employeeTracking/saveEmployeeTracking";
export const locationUpdate =
  "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8081/sales/employeeTracking/updateEmployeeTracking";
export const reasonDropDown =
  "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8091/dynamic-forms/dropdown";
export const getDetailsByempIdAndorgId =
  "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8081/sales/employeeTracking/getDetailsByempIdAndorgId";
export const getLocationCoordinates =
  "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8081/sales/employeeTracking/getLocationByempIdAndorgId";
  
// Dev End Points with JWT
const baseUrl =
  "http://ec2-15-207-225-163.ap-south-1.compute.amazonaws.com:8008/";
export const auth_url = baseUrl + "auth";
export const hrms_url = baseUrl + "hrms";
export const inventory_url = baseUrl + "inventory";
export const ops_url = baseUrl + "ops";
export const roleManagement_url = baseUrl + "role-management";
export const sales_url = baseUrl + "sales";
export const vehicleInfoService_url = baseUrl + "vehicle-information-service";
export const notificationServices_url = baseUrl + "notification-service";
export const profileImageUpdate = sales_url + "/employeeprofilepic";
export const getEmployeeList = sales_url + "/employees/reporting/all/emp";
export const getReportingMangerList =
  sales_url + "/employees/all/reportingManagers/orgId";
export const updateEmployeeTaskDelegate = sales_url + "/employees/emp";
export const getTaskList = sales_url + "/task-delegation/get_task_list";
export const deleteModelCard = sales_url + "/lead";

export const dashboard = baseUrl + "dfd/dashboard";

export const salesGap = baseUrl + "dfd/sales-gap";
export const getBranch = baseUrl + "dfd/oh";
export const tasktransfer = baseUrl + "dfd/sales-gap/target-dropdown";
export const getLeaderBoardData =
  baseUrl + "dfd/dashboard/v2/get_emp_target_ranking/org";
export const getBranchRankingData =
  baseUrl + "dfd/dashboard/v2/get_emp_target_ranking";

export const vehicleServices_url = baseUrl + "dfdl/vehicle-services";

export const dashboardLiveLeads = baseUrl + "dfdl";

export const dynamicReports_url = baseUrl + "dfdg/dynamic-reports";
export const dynamicForms = baseUrl + "dfdg/dynamic-forms";
export const orgnaizationHirarchy = baseUrl + "dfdg/oh";
export const dfGetAll = baseUrl + "dfdg/df-get-all";
export const subSourceAllDetails = baseUrl + "dfdg/Source_SubSource_AllDetails";
export const lostSubLost = baseUrl + "dfdg/Lost_SubLost_AllDetails";

export const getEnquiryVehicleModelData =
  baseUrl + "dfdg/Other_Maker_AllDetails";

export const downloadFile = baseUrl + "dfdr/dynamic-reports";

export const downloadFile1 =
  baseUrl + "etv-schd/dynamic-reports/etvbrl_report_download";
export const downloadFile2 = baseUrl + "etv-schd/dynamic-reports/etvbrl_report";
export const getEmployeeData =
  baseUrl + "role-management/employee/dept-employees";

export const notification =
  "http://automatestaging-1871827587.ap-south-1.elb.amazonaws.com:8096/notificationMaster";
// not getting used anywhere so not changes and commented
// export const admin_url =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8082/admin";

// export const customerService_url =
//   "http://automatestaging-724985329.ap-south-1.elb.amazonaws.com:8085/customer-service";

const URL = {
  // LOGIN: () => hrms_url + "/emplogin",
  LOGIN: () => auth_url + "/signin",

  REFRESHTOKEN: () => auth_url + "/refreshtoken",

  LEADS_LIST_API: () => sales_url + "/lead/all",
  GET_LEADS_LIST: (stage, empId, offset) => {
    return (
      sales_url +
      `/lead/all?limit=500&offset=${offset}&status=${stage}&empId=${empId}`
    );
  },
  DELETE_MODEL_CARD: (value) => {
    return deleteModelCard + `/delete_leadProduct?id=${value}`;
  },
  LEADS_LIST_API_FILTER: () => sales_url + "/lead/allByDate",
  MENULIST_API: (userName) => {
    return roleManagement_url + "/user/" + userName;
  },
  VEHICLE_MODELS: (orgId) => {
    return (
      vehicleInfoService_url + "/api/vehicle_details/?organizationId=" + orgId
    );
  },
  ENQUIRY_VEHICLE_MODELS: (orgId) => {
    return getEnquiryVehicleModelData + "?organizationId=" + orgId;
  },
  GET_EMPID: (userName) => {
    return roleManagement_url + "/user/" + userName;
  },
  GET_CALL_RECORDING_EXTENSIONID: (userName, orgId) => {
    return (
      sales_url +
      "/callrecording/getCallLoginDetails?orgId=" +
      orgId +
      "&empId=" +
      userName
    );
  },
  CUSTOMER_TYPE: (orgId) => {
    return sales_url + `/master-data/customertype/${orgId}`;
  },
  MY_TASKS: () => sales_url + "/workflow/assignedTasks?",
  CONTACT_DETAILS: (universalId) => {
    return sales_url + "/lead/id/" + universalId;
  },
  NO_THANKS: (leadId) => {
    return roleManagement_url + `/nothanks?leadId=${leadId}`;
  },
  TASKS_PRE_ENQUIRY: () => sales_url + "/workflow/lead/universalId/",
  ASSIGN_TASK: () => sales_url + "/dms/task",
  CHANGE_ENQUIRY_STATUS: () => sales_url + "/dms/lead/stage/",
  SOURCE_OF_ENQUIRY_ENQUIRY: (sourceOfEnquiryId, orgId, branchId) => {
    return (
      sales_url +
      "/employees/source-of-enquiry/" +
      `${sourceOfEnquiryId}/${orgId}/${branchId}`
    );
  },
  SALES_CONSULTANT: () => sales_url + "/lead/sales-consultant/manual",
  CREATE_CONTACT: () => sales_url + "",
  ENQUIRY_DETAILS: (universalId) => {
    return sales_url + "/enquiry/lead/id/" + `${universalId}`;
  },
  PROFORMA_LOGO_NAME: (orgId, branchId) => {
    return (
      sales_url + "/enquiry/performa/orgId/" + orgId + "/branchId/" + branchId
    );
  },

  PROFORMA_LISTING_DETAILS: (crmUniversalId) => {
    return sales_url + "/enquiry/performa/id/" + crmUniversalId;
  },

  PROFORMA_TERMS_N_CONDITIONS: (orgId) => {
    return sales_url + "/org/config/" + orgId + "/PROFORMA_TANDC";
  },

  ENQUIRY_DETAILS_BY_AUTOSAVE: (universalId) => {
    return downloadFile + "/autosave-get-uid/" + `${universalId}`;
  },
  UPDATE_ENQUIRY_DETAILS: () => sales_url + "/enquiry/lead",
  GET_RULES_CONFIG: (modal, variant, fuel, orgid) => {
    return (
      sales_url +
      "/allotment/rulesConfiguration" +
      `?model=${modal}&variant=${variant}&fuel=${fuel}&orgId=${orgid}`
    );
  },
  GET_CUSTOMER_TYPES: (orgId) => {
    return sales_url + `/master-data/customertype/${orgId}`;
  },
  DROP_ENQUIRY: () => sales_url + "/lead-drop",
  UPLOAD_DOCUMENT: () => sales_url + "/documents",
  UPLOAD_RANDOM_DOCUMENT: () => sales_url + "/documents/random-document",
  GET_ON_ROAD_PRICE_AND_INSURENCE_DETAILS: (varientId, vehicleId) => {
    return (
      vehicleInfoService_url +
      `/api/vehicle_on_road_prices/${varientId}/${vehicleId}`
    );
  },
  GET_PAID_ACCESSORIES_LIST: (vehicleId) => {
    return (
      inventory_url +
      `/inventory/accessories/${vehicleId}?pageNo=0&pageSize=100`
    );
  },
  GET_PAID_ACCESSORIES_LIST2: (vehicleId, orgId) => {
    return sales_url + `/allotment/${vehicleId}/${orgId}`;
  },
  GET_ON_ROAD_PRICE_DTO_LIST: (leadId) => {
    return sales_url + `/on-road-price/lead/${leadId}`;
  },
  SAVE_PROFORMA_DETAILS: () => {
    return sales_url + `/enquiry/performaDetails`;
  },
  SEND_ON_ROAD_PRICE_DETAILS: () => sales_url + "/on-road-price",
  GET_ALL_OFFERS: (varientId, vehicleId) => {
    return (
      ops_url +
      "/api/allofferdetail" +
      `?varientId=${varientId}&vehicleId=${vehicleId}`
    );
  },
  GET_TASK_DETAILS: (taskId) => {
    return sales_url + `/workflow/task/${taskId}`;
  },
  GET_TEST_DRIVE_DSE_LIST: (orgId) => {
    return roleManagement_url + `/user/role/name/Testdrive_DSE/${orgId}`;
  },
  GET_DRIVERS_LIST: (orgId) => {
    return roleManagement_url + `/user/role/name/Driver/${orgId}`;
  },
  GET_TEST_DRIVE_VEHICLES: (branchId, orgId) => {
    return (
      inventory_url +
      `/demoVehicle/vehicles?branchId=${branchId}&orgId=${orgId}&type=TESTDRIVE`
    );
  },
  GET_CURRENT_TASK_LIST: () => {
    return sales_url + `/task-history/current-day-task?`;
  },
  GET_FEATURE_PENDING_TASK_LIST: (empId, offset) => {
    return sales_url + `/task-history/future-or-past-tasks?`;
  },
  BOOK_TEST_DRIVE_APPOINTMENT: () => ops_url + "/testdrive/appointment",
  UPDATE_TEST_DRIVE_TASK: () => sales_url + "/dms/updateTestDriveTask",
  GET_TEST_DRIVE_APPOINTMENT_DETAILS: (entityModuleId, branchId, orgId) => {
    return (
      ops_url +
      `/testdrive/history?branchId=${branchId}&filterType=TESTDRIVE&filterVal=${entityModuleId}&orgId=${orgId}`
    );
  },
  VALIDATE_TEST_DRIVE_DATE: (date, vehicleId) => {
    return (
      inventory_url +
      `/allotment/vehicle/allotments?allotmentDate=${date}&id=${vehicleId}`
    );
  },
  CUSTOMER_LEAD_REFERENCE: () => sales_url + "/lead-customer-reference",
  GET_COMPLAINTS: () => dynamicReports_url + "/v2-generate-query",
  GET_EVENTS: () => {
    return ops_url + `/dms/getAllServiceEventsByFilterByStatus`;
  }, // getAllServiceEventsByFilter replaced by getAllServiceEventsByFilterByStatus
  GET_SOURCE_OF_ENQUIRY: (orgId) => {
    return subSourceAllDetails + `?organizationId=${orgId}`;
    //return sales_url + `/master-data/source-of-enquiry/${orgId}`;
  },
  GET_DROP_DATA: () => {
    return dynamicForms + "/dropdown";
  },
  PRE_BOOKING_PAYMENT: () => {
    return sales_url + "/payment";
  },
  BOOKING_AMOUNT: () => {
    return sales_url + "/booking-amount";
  },
  GET_PRE_BOOKING_PAYMENT_DETAILS: (leadId) => {
    return sales_url + `/payment?leadId=${leadId}`;
  },
  GET_BOOKING_AMOUNT_DETAILS: (leadId) => {
    return sales_url + `/booking-amount/lead/${leadId}`;
  },
  GET_ASSIGNED_TASKS_AT_PRE_BOOKING: (universalId) => {
    return sales_url + `/workflow/lead/stage/${universalId}`;
  },
  GET_EVENT_LIST: (startDate, endDate, empId) => {
    return (
      ops_url +
      `/dms/getAllServiceEventsByFilterWithoutPagination?startdate=${startDate}&enddate=${endDate}&organiserid=${empId}`
    );
  },
  GENERATE_OTP: () => {
    return notificationServices_url + "/generateOTP";
  },
  VALIDATE_OTP: () => {
    return notificationServices_url + "/validateOTP";
  },
  ORG_HIRARCHY: (orgId, branchId) => {
    return orgnaizationHirarchy + `/active-levels/${orgId}/${branchId}`;
  },
  LEAD_SOURCE_DATA: () => dashboard + "/v2/get_leadsource_data",
  VEHICLE_MODEL_DATA: () => dashboard + "/v2/get_vehicle_model_data",
  EVENT_DATA: () => dashboard + "/v2/get_events_data",
  TASKS_DATA: () => dashboard + "/v2/get_todays_data",
  GET_LOST_DROP_CHART_DATA: () => dashboard + "/v2/get_lostdrop_data",
  UPDATE_SINGLEAPPROVAL: () => {
    return sales_url + "/lead-drop";
  },
  LEAD_DROPPED: () => sales_url + "/lead",
  UPDATE_BULKAPPROVAL: () => {
    return sales_url + "/lead-drop/bulkdrop";
  },
  REVOKE: (id) => {
    return sales_url + "/lead-drop/updateStatusEnquire/ENQUIRY/" + id;
  },
  GET_LEADDROP_LIST: (
    branchId,
    empName,
    orgId,
    offSet,
    limit,
    startDate,
    endDate
  ) => {
    return (
      sales_url +
      "/lead-drop/details?branch=" +
      branchId +
      "&limit=" +
      limit +
      "&loginUser=" +
      empName +
      "&offset=" +
      offSet +
      "&orgId=" +
      orgId +
      `&startdate=${startDate}&enddate=${endDate}`
    );
  },
  GET_SUB_MENU: (stage) => {
    return sales_url + "/lead/stagedropdown?menu=" + stage;
  },
  GET_LEAD_LIST: (branchId, empName, empId, offSet, limit) => {
    return (
      sales_url +
      "/lead/allLeads?limit=" +
      limit +
      "&offset=" +
      offSet +
      "&empId=" +
      empId +
      "&branchId=" +
      branchId +
      "&empName=" +
      empName
    );
  },
  GET_LEAD_LIST_2: () => {
    return sales_url + "/lead/allByDateNew";
  },
  GET_ALL_STATUS: () => {
    return sales_url + "/lead/alldatadropdown";
  },
  GET_MENU_DROP_DOWN_DATA: () => {
    return sales_url + "/lead/menudropdown";
  },
  GET_EMPLOYEES_DROP_DOWN_DATA: (orgId, employeeId) => {
    return orgnaizationHirarchy + `/active-dropdowns/${orgId}/${employeeId}`;
  },
  GET_EMPLOYEES_ACTIVE_BRANCHES: (orgId, employeeId) => {
    return orgnaizationHirarchy + `/active-branches/${orgId}/${employeeId}`;
  },
  GET_EMPLOYEES_ROLES: (employeeId) => {
    return salesGap + `/get_employee_role/${employeeId}`;
  },
  ADD_TARGET_MAPPING: () => salesGap + `/add_targetmapping_role`,
  EDIT_TARGET_MAPPING: () => salesGap + `/edit_targetmapping_role`,
  GET_ALL_TARGET_MAPPING: () => salesGap + `/get_all_targetmapping_role`,
  GET_ALL_TARGET_MAPPING_SEARCH: () =>
    salesGap + `/get_all_target_mapping_search`,
  GET_TARGET_PLANNING_COUNT: () => salesGap + `/get_target_planning_count`,
  GET_TARGET_PARAMS: () => dashboard + "/v2/get_target_params",
  GET_TARGET_PARAMS_ALL: () => dashboard + "/v2/get_target_params_for_all_emps",
  GET_TARGET_PARAMS_EMP: () => dashboard + "/v2/get_target_params_for_emp",
  GET_SALES_DATA: () => dashboard + "/v2/get_sales_data",
  GET_SALES_COMPARISON_DATA: () => dashboard + "/v2/get_sales_comparsion_data",
  GET_TARGET_GROUP_RANKING: (orgId) => {
    return `${dashboard}/v2/get_emp_target_ranking/org/${orgId}`;
  },
  GET_TARGET_RANKING: (orgId, branchId) => {
    return `${dashboard}/v2/get_emp_target_ranking/org/${orgId}/branch/${branchId}`;
  },
  GET_BANK_DETAILS: (orgId) => {
    return dfGetAll + `/${orgId}/"Active"/${orgId}/bankFinancier`;
  },
  GET_INSURENCE_COMPANY_NAMES: (orgId) => {
    return dfGetAll + `/${orgId}/"Active"/${orgId}/incuranceCompany`;
  },
  GET_DROP_LIST: (ordId, type) => {
    return lostSubLost + `?organizationId=${ordId}&stageName=${type}`;
  },
  GET_MY_TASKS_NEW_DATA: () => {
    return dashboard + "/v2/get_todays_datav2";
  },
  GET_WORK_FLOW_TASKS: (universalId) => {
    return sales_url + `/workflow/lead/universalId/${universalId}`;
  },
  UPLOAD_PROFILE: (ownerId, orgId, branchId) => {
    return (
      sales_url +
      `/documents/uploadEmployeeProfile?ownerId=${ownerId}&orgId=${orgId}&branchId=${branchId}`
    );
  },
  SAVE_PROFILE: () => {
    return sales_url + `/employeeprofilepic/save`;
  },
  CHANGE_PASSWORD: (cognitoName) => {
    return hrms_url + `/changepassword/${cognitoName}`;
  },
  UPDATE_REF: () => {
    return sales_url + `/lead-customer-reference/update`;
  },
  GET_BRANCH: () => {
    return getBranch + `/data-nodes?orgId=1&levelCode=Level5`;
  },
  DOWNLOAD_FILE: () => {
    return downloadFile2;
  },
  LOCATION_LIST: (orgId) => {
    return `${baseUrl} + "dfd/oh/data-nodes?orgId=${orgId}&levelCode=Level4`;
  },
  DEALER_CODE_LIST: (orgId) => {
    return `${baseUrl} + "dfd/oh/data-nodes?orgId=1&levelCode=Level5`;
  },
  DOWNLOAD_REPORT: () => {
    return baseUrl + "dfdr/dynamic-reports/etvbrl_report";
  },

  QR: (orgId, branchId) => {
    return sales_url + `/qrcode/get/${orgId}/${branchId}`;
  },
  GET_VEHICAL_MODAL: () => {
    return vehicleInfoService_url + `/api/vehicle_details/vehicle_models`;
  },
  GET_SPECIAL_DROP_VALUE: () => {
    return dynamicForms + `/dropdown`;
  },
  AUTO_SAVE: () => {
    return downloadFile + `/autosave`;
  },
  REASON_LIST: (orgId, taskName) => {
    return `${downloadFile}/get-followup/${orgId}/${taskName}`;
  },
  TARGET_DROPDOWN: (orgId, parent, child, parentId) => {
    return `${tasktransfer}?orgId=${orgId}&parent=${parent}&child=${child}&parentId=${parentId}`;
  },
  GET_TASK_LIST: (taskId) => {
    return `${getTaskList}/${taskId}`;
  },
  GET_TEAMS_TARGET_PARAMS: () =>
    dashboard + "/v4/get_target_params_for_all_emps",
  // GET_TOTAL_TARGET_PARAMS: () => dashboard + "/v4/get_target_params",
  GET_TOTAL_TARGET_PARAMS: () => dashboard + "/v2/get_target_params",
  GET_EMPLOYEE_DETAILS: (orgId, branchId, deptId, desigId) => {
    return `${getEmployeeData}?orgId=${orgId}&branchId=${branchId}&deptId=${deptId}&desigId=${desigId}`;
  },
  GET_EMPLOYEE_LIST: (empId) => {
    return `${getEmployeeList}/${empId}`;
  },
  GET_REPORTING_MANAGER_LIST: (orgId) => {
    return `${getReportingMangerList}/${orgId}/for/dropdown`;
  },
  EMPLOYEE_DATA_UPDATE: (empID, managerID) => {
    return `${updateEmployeeTaskDelegate}/${empID}/reportingManager/${managerID}/update`;
  },
  TARGET_DROPDOWN: (orgId, parent, child, parentId) => {
    return `${tasktransfer}?orgId=${orgId}&parent=${parent}&child=${child}&parentId=${parentId}`;
  },
  GET_TASK_LIST: (taskId) => {
    return `${getTaskList}/${taskId}`;
  },
  GET_EMPLOYEE_DETAILS: (orgId, branchId, deptId, desigId) => {
    return `${getEmployeeData}?orgId=${orgId}&branchId=${branchId}&deptId=${deptId}&desigId=${desigId}`;
  },
  GET_LEADERBOARD_DATA: (orgId) => {
    return `${getLeaderBoardData}/${orgId}`;
  },
  GET_BRANCH_RANKING_DATA: (orgId, branchId) => {
    return getBranchRankingData + "/org/" + orgId + "/branch/" + branchId;
  },
  EMPLOYEE_DATA_UPDATE: (empID, managerID) => {
    return `${updateEmployeeTaskDelegate}/${empID}/reportingManager/${managerID}/update`;
  },
  TARGET_DROPDOWN: (orgId, parent, child, parentId) => {
    return `${tasktransfer}?orgId=${orgId}&parent=${parent}&child=${child}&parentId=${parentId}`;
  },
  GET_TASK_LIST: (empId) => {
    return `${getTaskList}/${empId}`;
  },
  GET_EMPLOYEE_DETAILS: (orgId, branchId, deptId, desigId) => {
    return `${getEmployeeData}?orgId=${orgId}&branchId=${branchId}&deptId=${deptId}&desigId=${desigId}`;
  },
  TRANSFER_TASK: (fromUserId, toUserId) => {
    return (
      sales_url +
      `/task-delegation/process/selected?emplIdFrom=${fromUserId}&emplIdTo=${toUserId}`
    );
  },
  UPDATE_SELF_TARGET_PARAMS: () => {
    return `${salesGap}/target-update1`;
  },
  UPDATE_TEAM_TARGET_PARAMS: () => {
    return `${salesGap}/target-update`;
  },
  MODEL_SOURCE_SELF: () =>
    `${dashboard}/v2/get_target_params_for_emp_model_source`,
  GET_LIVE_LEADS_MODEL_SOURCE_SELF: () =>
    `${dashboardLiveLeads}/dashboard/v2/get_target_params_for_emp_model_source`,
  GET_LIVE_LEADS_MODEL_SOURCE_INSIGHTS: () =>
    `${dashboardLiveLeads}/dashboard/v2/get_target_params_model_source`,
  GET_LIVE_LEADS_MODEL_SOURCE_TEAM: () =>
    `${dashboardLiveLeads}/dashboard/v4/get_target_params_for_all_emps_model_source`,
  MODEL_SOURCE_INSIGHTS: () => `${dashboard}/v2/get_target_params_model_source`,
  MODEL_SOURCE_TEAM: () =>
    `${dashboard}/v4/get_target_params_for_all_emps_model_source`,
  GET_LIVE_LEADS_SELF: () =>
    `${dashboardLiveLeads}/dashboard/v2/get_target_params_for_emp`,
  GET_LIVE_LEADS_INSIGHTS: () =>
    `${dashboardLiveLeads}/dashboard/v2/get_target_params`,
  GET_LIVE_LEADS_TEAM: () =>
    `${dashboardLiveLeads}/dashboard/v4/get_target_params_for_all_emps`,
  GET_TOTAL_OF_TEAM: () =>
    `${dashboard}/v2/get_target_params_immediate_hierarchy`,
  GET_ATTENDANCE_EMPID: (empId, orgId, month) => {
    return (
      sales_url +
      "/employeeAttendance/getAttendanceByempIdAndorgId" +
      `/${empId}/${orgId}/${month}`
    );
  },
  GET_ATTENDANCE_EMPID2: (empId, orgId, start, end) => {
    return (
      sales_url +
      "/employeeAttendance/getDataByFilter" +
      `/${empId}/${orgId}/${start}/${end}`
    );
  },
  GET_ATTENDANCE_COUNT: (empId, orgId, month) => {
    return (
      sales_url +
      "/employeeAttendance/attendanceCount" +
      `/${empId}/${orgId}/${month}`
    );
  },
  GET_ATTENDANCE_COUNT2: (empId, orgId, start, end) => {
    return (
      sales_url +
      "/employeeAttendance/filterattendanceCount" +
      `/${empId}/${orgId}/${start}/${end}`
    );
  },
  NOTIFICATION_LIST: (empId) => {
    return notification + `/notification/${empId}`;
  },
  SAVE_EMPLOYEE_ATTENDANCE: () => {
    return sales_url + "/employeeAttendance/saveEmployeeAttendance";
  },
  UPDATE_EMPLOYEE_ATTENDANCE: (id) => {
    return (
      sales_url + "/employeeAttendance/updateEmployeeAttendance" + `/${id}`
    );
  },
  DELETE_EMPLOYEE_ATTENDANCE: (id) => {
    return (
      sales_url + "/employeeAttendance/deleteEmployeeAttendance" + `/${id}`
    );
  },
  GET_EMPLOYEES_ATTENDANCE_DETAILS: () => {
    return sales_url + "/employeeAttendance/getEmployeeAttendanceDetails";
  },
  GET_LOCATION: (empId, orgId) =>
    getDetailsByempIdAndorgId + `/${empId}/${orgId}`,
  GET_LOCATION_COORDINATES: (empId, orgId) =>
    getLocationCoordinates + `/${empId}/${orgId}`,
  ENQURIY_ACCOUNT: () => {
    return sales_url + `/account/enquiryAccount?allocateDse=false`;
  },
  ENQUIRY_CONTACT: () => {
    return sales_url + `/contact/enquiryContact?allocateDse=false`;
  },
  RECEPTIONIST_DASHBOARD: () => {
    return dashboard + "/receptionist";
  },
  RECEPTIONIST_SOURCE: () => {
    return dashboard + "/receptionist/source";
  },
  RECEPTIONIST_MODEL: () => {
    return dashboard + "/receptionist/model";
  },
  ROLE_STAGE_ACCESS: (role) => {
    return sales_url + "/lead/roleStageAccess/" + role;
  },
  GET_TASK_360_HISTORY: (universalId) => {
    return sales_url + "/workflow/universalId/" + universalId;
  },
};

// bankFinancier, incuranceCompany, enqueryCategory, deliveryCheckList, sublostReason
// http://liveautomate-345116193.ap-south-1.elb.amazonaws.com:8091/df-get-all/1/%22Active%22/1/enqueryCategory

// http://ec2-3-109-65-7.ap-south-1.compute.amazonaws.com:8083/oh/active-dropdowns/13/412
export default URL;
