
export const USER_NAME = "USER_NAME";
export const USER_TOKEN = "USER_TOKEN";
export const EMP_ID = "EMP_ID";
export const ORG_ID = "ORG_ID";
export const REFRESH_TOKEN = "REFRESH_TOKEN";
export const IS_USER_LOGGED_IN = "IS_USER_LOGGED_IN";
export const TOKEN_EXPIRES_IN = "TOKEN_EXPIRES_IN";
export const LOGIN_EMPLOYEE = "LOGIN_EMPLOYEE";
export const SELECTED_BRANCH_ID = "SELECTED_BRANCH_ID";
export const SELECTED_BRANCH_NAME = "SELECTED_BRANCH_NAME"
export const ENQ_PAYLOAD = "ENQ_PAYLOAD"
export const UNIVERSAL_ID = "UNIVERSAL_ID"
export const IS_LOGIN = "IS_LOGIN"
export const EXTENSION_ID = "EXTENSION_ID"
export const EXTENSSION_PWD ="EXTENSSION_PWD"
export const TARGET = "TARGET_EMP";