import React from "react";
import { View, Text } from "react-native";

const InActiveScreen = ({ navigation }) => {
  return (
    <View>
      <Text>InActive</Text>
    </View>
  );
};

export default InActiveScreen;
