import React from "react";
import { View, Text } from "react-native";

const detailsOverviewComp = () => {
  return (
    <View>
      <Text>details overview</Text>
    </View>
  );
};
export default detailsOverviewComp;
