import React, { useEffect, useState } from "react";
import { createMaterialTopTabNavigator } from "@react-navigation/material-top-tabs";
import PreEnquiryScreen from "../scenes/mainScenes/EMS/preEnquiryScreen";
import EnquiryScreen from "../scenes/mainScenes/EMS/enquiryScreen";
import PreBookingScreen from "../scenes/mainScenes/EMS/prebookingScreen";
import BookingScreen from "../scenes/mainScenes/EMS/bookingScreen";

import { Colors } from "../styles";
import * as AsyncStore from "../asyncStore";
import ProceedToBookingScreen from "../scenes/mainScenes/MyTasks/proceedToBookingScreen";
import Leads from "../scenes/mainScenes/EMS/leadsScreen";

export const EmsTopTabNavigatorIdentifiers = {
  preEnquiry: "PRE_ENQUIRY",
  leads: 'LEADS',
  enquiry: "ENQUIRY",
  preBooking: "PRE_BOOKING",
  booking:"BOOKING",
  proceedToBooking: 'PROCEED_BOOKING'
};

const EMSTopTab = createMaterialTopTabNavigator();

const tabBarOptions = {
  activeTintColor: Colors.RED,
  inactiveTintColor: Colors.DARK_GRAY,
  indicatorStyle: {
    backgroundColor: Colors.RED,
  },
  labelStyle: {
    fontSize: 12,
    fontWeight: "600",
  },
}

const EMSTopTabNavigatorOne = () => {

  return (
    <EMSTopTab.Navigator
      initialRouteName={EmsTopTabNavigatorIdentifiers.preEnquiry}
      tabBarOptions={tabBarOptions}
    >
      <EMSTopTab.Screen
        name={EmsTopTabNavigatorIdentifiers.preEnquiry}
        component={PreEnquiryScreen}
        options={{ title: "Contacts" }}
      />
    </EMSTopTab.Navigator>
  );
};

const EMSTopTabNavigatorTwo = () => {

  return (
    <EMSTopTab.Navigator
      initialRouteName={EmsTopTabNavigatorIdentifiers.preEnquiry}
      tabBarOptions={tabBarOptions}
    >
      <EMSTopTab.Screen
        name={EmsTopTabNavigatorIdentifiers.preEnquiry}
        component={PreEnquiryScreen}
        options={{ title: "Contacts",  }}

      />
      <EMSTopTab.Screen
        name={EmsTopTabNavigatorIdentifiers.leads}
        component={Leads}
        options={{ title: "Leads",  }}

      />
      {/*<EMSTopTab.Screen*/}
      {/*  name={EmsTopTabNavigatorIdentifiers.enquiry}*/}
      {/*  component={EnquiryScreen}*/}
      {/*  options={{ title: "Enquiry" }}*/}
      {/*/>*/}
      {/*<EMSTopTab.Screen*/}
      {/*  name={EmsTopTabNavigatorIdentifiers.preBooking}*/}
      {/*  component={PreBookingScreen}*/}
      {/*  options={{ title: "Booking Approval" }}*/}
      {/*/>*/}
      {/*<EMSTopTab.Screen*/}
      {/*  name={EmsTopTabNavigatorIdentifiers.booking}*/}
      {/*  component={BookingScreen}*/}
      {/*  options={{ title: "Booking View" }}*/}
      {/*/>*/}
      {/* <EMSTopTab.Screen
        name={EmsTopTabNavigatorIdentifiers.proceedToBooking}
        component={ProceedToBookingScreen}
        initialParams={{ accessoriesList: [] }}
        options={{ title: "Proceed To Booking" }}
      /> */}
    </EMSTopTab.Navigator>
  );
};

export { EMSTopTabNavigatorOne, EMSTopTabNavigatorTwo };
