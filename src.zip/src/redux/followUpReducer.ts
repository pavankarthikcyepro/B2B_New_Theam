import { createSlice } from "@reduxjs/toolkit";

const slice = createSlice({
  name: "PREBOOKING_FOLLOWUP_SLICE",
  initialState: {},
  reducers: {},
});

export const {} = slice.actions;
export default slice.reducer;
