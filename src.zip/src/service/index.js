import Geolocation from "@react-native-community/geolocation";
import BackgroundService from "react-native-background-actions";
import { Colors } from "../styles";

export const officeRadius = 5;
export const sleep = (time) =>
  new Promise((resolve) => setTimeout(() => resolve(), time));

// You can do anything in your task such as network requests, timers and so on,
// as long as it doesn't touch UI. Once your task completes (i.e. the promise is resolved),
// React Native will go into "paused" mode (unless there are other tasks running,
// or there is a foreground app).
export const veryIntensiveTask = async (taskDataArguments) => {
  // Example of an infinite loop task
  const { delay } = taskDataArguments;
  await new Promise(async (resolve) => {
    for (let i = 0; BackgroundService.isRunning(); i++) {
      console.log(i);
      try {
        await Geolocation.watchPosition(
          (lastPosition) => {
            console.log(lastPosition);
              var newLatLng = {
                latitude: lastPosition.coords.latitude,
                longitude: lastPosition.coords.longitude,
              };
          },
          (error) => alert(JSON.stringify(error)),
          { enableHighAccuracy: true, distanceFilter: 100 }
        );
        Geolocation.watchPosition((data) => {
          console.log("LOACATION", data);
        });
      } catch (error) {}

        await BackgroundService.updateNotification({
          taskTitle: "test"
        })
      await sleep(delay);
    }
  });
};

export const options = {
  taskName: "Cypro",
  taskTitle: "Cypro",
  taskDesc: "Cypro is tracking",
  taskIcon: {
    name: "@mipmap/cy",
    type: "mipmap",
  },
  color: Colors.PINK,
  linkingURI: "yourSchemeHere", // See Deep Linking for more info
  parameters: {
    delay: 10000,
  },
};

export function getDistanceBetweenTwoPoints(lat1, lon1, lat2, lon2) {
  if (lat1 == lon1?.lat && lat2 == lon2) {
    return 0;
  }

  const radlat1 = (Math.PI * lat1) / 180;
  const radlat2 = (Math.PI * lat2) / 180;

  const theta = lon1 - lon2;
  const radtheta = (Math.PI * theta) / 180;

  let dist =
    Math.sin(radlat1) * Math.sin(radlat2) +
    Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);

  if (dist > 1) {
    dist = 1;
  }

  dist = Math.acos(dist);
  dist = (dist * 180) / Math.PI;
  dist = dist * 60 * 1.1515;
  dist = dist * 1.609344; //convert miles to km

  return dist;
}

export function createDateTime(time) {
  var splitted = time.split(":");
  if (splitted.length != 2) return undefined;

  var date = new Date();
  date.setHours(parseInt(splitted[0], 10));
  date.setMinutes(parseInt(splitted[1], 10));
  date.setSeconds(0);
  return date;
}
