
import React, { useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { AuthNavigator, AppNavigator } from './navigations';
import { AuthStackNavigator } from './navigations/authNavigator';
import { MainStackDrawerNavigator, MainStackNavigator } from './navigations/appNavigator';
import { Provider } from 'react-redux';
import reduxStore from './redux/reduxStore';
import * as AsyncStore from './asyncStore';
import { AuthContext } from './utils/authContext';
import { enableScreens } from 'react-native-screens';

enableScreens();

const AppScreen = () => {

    const [state, dispatch] = React.useReducer((prevState, action) => {
        switch (action.type) {
            case "RESTORE_TOKEN":
                return {
                    ...prevState,
                    userToken: action.token,
                    isLoading: false
                }
            case "SIGN_IN":
                return {
                    ...prevState,
                    isSignout: false,
                    userToken: action.token,
                }
            case "SIGN_OUT":
                return {
                    ...prevState,
                    isSignout: true,
                    userToken: null,
                }
        }
    }, {
        isLoading: true,
        isSignout: false,
        userToken: null,
    })


    useEffect(async () => {

        const checkUserToken = async () => {
            let userToken = await AsyncStore.getData(AsyncStore.Keys.USER_TOKEN);
            dispatch({ type: 'RESTORE_TOKEN', token: userToken });
        };

        checkUserToken();
    }, [])

    const authContext = React.useMemo(
        () => ({
            signIn: async (token) => {
                dispatch({ type: 'SIGN_IN', token: token });
            },
            signOut: () => {
                AsyncStore.storeData(AsyncStore.Keys.USER_TOKEN, "");
                dispatch({ type: 'SIGN_OUT' });
            },
            signUp: async data => {
                dispatch({ type: 'SIGN_IN', token: 'dummy-auth-token' });
            },
        }),
        []
    );

    return (
        <AuthContext.Provider value={authContext}>
            <Provider store={reduxStore}>
                <NavigationContainer>
                    {state.userToken ? <MainStackNavigator /> : <AuthStackNavigator />}
                </NavigationContainer>
            </Provider>
        </AuthContext.Provider>
    )
}

export default AppScreen;
