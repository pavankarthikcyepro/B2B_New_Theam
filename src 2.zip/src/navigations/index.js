
import * as AuthNavigator from './authNavigator';
import * as AppNavigator from './appNavigator';

export { AuthNavigator, AppNavigator };